#importing datetime
import datetime as DT

#defining the current date
CurDate = DT.datetime.now()

#setting up characters to remove
BadChars = ['(', ')',"'","\n"]

#reading the data from defaults.dat
f = open("defaults.dat", "r")
CurLine = 1

#making variables equal the data in the .dat file when it is on a ceretain line
for Line in f:
    if CurLine == 1:
            NextTransactionNum = int(Line)
    if CurLine == 2:
            NextDriverNum = int(Line)
    if CurLine == 3:
            MonthStandFee = float(Line)
    if CurLine == 4:
            DailyRentFee = float(Line)
    if CurLine == 5:
            WeeklyRentFee = float(Line)
    if CurLine == 6:
            HSTRate = float(Line)
    CurLine = CurLine + 1

#closing the .dat file
f.close()

#checing if it is the first of the month
CurDay = CurDate.strftime("%d")
CurDatePrint = CurDate.strftime("%Y-%m-%d")
if CurDay == "01":
    h = open('employees.dat', 'r')
    g = open('defaults.dat', 'w')
    f = open('revenue.dat', 'a')

    for Line in h:
        for R in BadChars:
            Line = Line.replace(R, '')
        Line = Line.split(",")


        #writing the stand fees to the revinue file
        f.write(f"{NextTransactionNum,CurDatePrint,'Monthly Stand Fees',Line[0],MonthStandFee,(MonthStandFee * HSTRate),(MonthStandFee +(MonthStandFee * HSTRate))}\n")

        #updating the transaction number
        NextTransactionNum = NextTransactionNum + 1

        #writing the transaction number to the defaults
        with open('defaults.dat', 'w') as g:
            g.write(f"{NextTransactionNum + 1}\n")
            g.write(f"{NextDriverNum}\n")
            g.write(f"{MonthStandFee}\n")
            g.write(f"{DailyRentFee}\n")
            g.write(f"{WeeklyRentFee}\n")
            g.write(f"{HSTRate}\n")

    g.close()
    f.close()
    h.close()

    # writing the updated ammount to the employees table
    LineNum = 0
    h = open('employees.dat', 'r')

    # removing unwanted characters
    for Line in h:
        for R in BadChars:
            Line = Line.replace(R, '')
        Line = Line.split(",")

        # putting everything in a try loop so it doesent error
        try:

            # changing the ammount owed to add the monthly stand fee

            Line9New = float(Line[9]) + MonthStandFee

            # putting the list into a variable
            replacedtext = f"{Line[0], Line[1], Line[2], Line[3], Line[4], Line[5], Line[6], Line[7], Line[8], Line9New}" + '\n'

            #removing some character i dont want
            replacedtext = str(replacedtext).replace("', '", "','")

            # Open the file in read-only mode. In this case, we're simply just reading the contents of the file.
            with open('employees.dat', 'r') as givenfilecontent:

                # Get all the lines from the given file using the readlines() function
                filelines = givenfilecontent.readlines()

                # modify the (LineNum) line in the above lines with the replaced text using list indexing
                filelines[LineNum] = replacedtext

                # increasing the LineNum by 1 every loop
                LineNum = LineNum + 1

            # Open the file in write-only mode
            with open('employees.dat', 'w') as givenfilecontent:

                # Write the modified data to the same file again using writelines function
                givenfilecontent.writelines(filelines)

        # the required except for the try statement above
        except:
            break

    # closing the exmployees file
    h.close()
while True:
    #printing the program menu
    print("HAB Taxi Services")
    print("Company Services System")
    print("")
    print("1. Enter a New Employee (driver).")
    print("2. Enter Company Revenues.")
    print("3. Enter Company Expenses.")
    print("4. Track Car Rentals.")
    print("5. Record Employee Payment.")
    print("6. Print Company Profit Listing.")
    print("7. Print Driver Financial Listing.")
    print("8. Quit Program.")
    print("")

    #getting the user to enter the number for the option thy want to select
    Choice = input("Enter Choice (1-8)")

    #code stating that i did not code option 2 or 3 and insted decided to do option #1
    if Choice == "1":
        print("i chose to code option number 3 for this project")
    if Choice == "2":
        print("i chose to code option number 3 for this project")

    #entering company expenses if the user selects 3
    if Choice == "3":
        f = open('expenses.dat', 'a')

        #collecting the users input
        InvoiceNum = input("please enter the invoice number")
        InvoiceDate = input("please enter the invoice date (YYYY-MM-DD)")
        DriverNum = input("please enter the driver number")

        #collecting the information for the individual expenses
        while True:
            ItemNum = input("please enter the item number")
            ItemDesc = input("please enter the item description")
            ItemCost = float(input("please enter the item cost"))
            ItemAmm = int(input("please enter the ammount of the item purchased"))
            TotalCost = ItemCost * ItemAmm

            #making a variable for the list
            ExpensesPrint = f"{InvoiceNum,InvoiceDate,DriverNum,ItemNum,ItemDesc,ItemCost,ItemAmm,TotalCost}\n"

            # removing the spaces
            ExpensesPrint = str(ExpensesPrint).replace("', '", "','")

            # writing the info to the rentals.dat file
            f.write(ExpensesPrint)

            #asking the user if they would like to enter another item
            AnotherItem = input("would you like to enter another item? (Y or N)").upper()
            if AnotherItem == "N":
                break
        #closing the expense file
        f.close()

    #starting the code if the code if the user selected option 4
    if Choice == "4":

        #gathering the inputs from the user
        RentalID = input("what is the rental ID")
        DriverNum = input("what is the drivers number")
        StartDate = input("what is the start date of the rental (YYYY-MM-DD")
        CarNum = input("please enter the car number (1 - 4)")
        LenghtRent = input("is the car rented weekly or daily (W or D").upper()

        #doing calculations if the user selsected days
        if LenghtRent == "D":
            NumDays = int(input("how many days will the car be rented"))
            RentalCost = NumDays * DailyRentFee

        #doing calculations if the user selected weeks
        if LenghtRent == "W":
            NumWeeks = int(input("how many weeks will the car be rented"))
            NumDays = NumWeeks * 7
            RentalCost = NumWeeks * WeeklyRentFee

        #calculating HST and total
        RentHST = RentalCost * HSTRate
        RentTotal = RentalCost + RentHST

        #opening the files
        f = open('revenue.dat', 'a')
        g = open('defaults.dat', 'w')

        #writing to the revinue file
        f.write(f"{NextTransactionNum, CurDatePrint, 'Rental Fees', DriverNum, RentalCost, RentHST, RentTotal}\n")

        # writing the transaction number to the defaults
        with open('defaults.dat', 'w') as g:
            g.write(f"{NextTransactionNum + 1}\n")
            g.write(f"{NextDriverNum}\n")
            g.write(f"{MonthStandFee}\n")
            g.write(f"{DailyRentFee}\n")
            g.write(f"{WeeklyRentFee}\n")
            g.write(f"{HSTRate}\n")

        #closing the files
        f.close()
        g.close()

        #writing the updated ammount to the employees table
        LineNum = 0
        h = open('employees.dat', 'r')

        #removing unwanted characters
        for Line in h:
            for R in BadChars:
                Line = Line.replace(R, '')
            Line = Line.split(",")

            #putting everything in a try loop so it doesent error
            try:

                #changing the ammount owed if the driver number matches the list
                if Line[0] == DriverNum:
                    Line9New = float(Line[9]) + RentTotal
                else:
                    Line9New = Line[9]

                # Give the line text as static input add newline character at the end of it
                replacedtext = f"{Line[0],Line[1],Line[2],Line[3],Line[4],Line[5],Line[6],Line[7],Line[8],Line9New}" + '\n'

                replacedtext = str(replacedtext).replace("', '", "','")
                # Open the file in read-only mode. In this case, we're simply just reading the contents of the file.
                with open('employees.dat', 'r') as givenfilecontent:

                    # Get all the lines from the given file using the readlines() function
                    filelines = givenfilecontent.readlines()

                    # modify the (linenumb) line in the above lines with the replaced text using list indexing
                    filelines[LineNum] = replacedtext

                    # increasing the linenum by 1 every loop
                    LineNum = LineNum + 1

                # Open the file in write-only mode
                with open('employees.dat', 'w') as givenfilecontent:

                    # Write the modified data to the same file again using writelines function
                    givenfilecontent.writelines(filelines)

            #the required except for the try statement above
            except:
                break

        #closing the exmployees file
        h.close()

        #opening the rentals file
        f = open('rentals.dat', 'a')

        #assiging the list to a variable
        RentalsPrint = f"{RentalID,DriverNum,StartDate,CarNum,LenghtRent,NumDays,RentalCost,RentHST,RentTotal}\n"

        #removing the spaces
        RentalsPrint = str(RentalsPrint).replace("', '", "','")

        #writing the info to the rentals.dat file
        f.write(RentalsPrint)

    #executing the code for option 5 if the user selected it
    if Choice == "5":

        #collecting the user inputs
        PaymentID = input("what is the payment ID")
        DriverNum = input("what is the driver number")
        PayDate = input("what is the payment date (YYYY-MM-DD)")
        PayAmm = float(input("what is the payment ammount"))
        PayReason = input("what is the payment reason")
        PayMethod = input("what is the payment method (cash debit, or visa)").upper()

        #writing the updated ammount to the employees file
        LineNum = 0
        h = open('employees.dat', 'r')

        #removing unwanted characters
        for Line in h:
            for R in BadChars:
                Line = Line.replace(R, '')
            Line = Line.split(",")

            # putting everything in a try loop so it doesent error
            try:

                # changing the ammount owed if the driver number matches the list
                if Line[0] == DriverNum:
                    Line9New = float(Line[9]) - PayAmm
                else:
                    Line9New = Line[9]

                # Give the line text as static input add newline character at the end of it
                replacedtext = f"{Line[0], Line[1], Line[2], Line[3], Line[4], Line[5], Line[6], Line[7], Line[8], Line9New}" + '\n'

                replacedtext = str(replacedtext).replace("', '", "','")
                # Open the file in read-only mode. In this case, we're simply just reading the contents of the file.
                with open('employees.dat', 'r') as givenfilecontent:

                    # Get all the lines from the given file using the readlines() function
                    filelines = givenfilecontent.readlines()

                    # modify the (linenumb) line in the above lines with the replaced text using list indexing
                    filelines[LineNum] = replacedtext

                    # increasing the linenum by 1 every loop
                    LineNum = LineNum + 1

                # Open the file in write-only mode
                with open('employees.dat', 'w') as givenfilecontent:

                    # Write the modified data to the same file again using writelines function
                    givenfilecontent.writelines(filelines)

            # the required except for the try statement above
            except:
                break

        # closing the employees file
        h.close()

        # opening the payment file
        f = open('payment.dat', 'a')

        # assiging the list to a variable
        PaymentsPrint = f"{PaymentID, DriverNum, PayDate, PayAmm, PayReason, PayMethod}\n"

        # removing the spaces
        PaymentsPrint = str(PaymentsPrint).replace("', '", "','")

        # writing the info to the rentals.dat file
        f.write(PaymentsPrint)

    #starting the code for option 6 if the user selected it
    if Choice == "6":

        #getting the user to enter the start and end date
        StartDateHead = input("what is the start date of the report (YYYY-MM-DD)")
        EndDateHead = input("what is the end date of the report (YYYY-MM-DD)")

        #converting the start and end date to strptime
        StartDate = DT.datetime.strptime(StartDateHead, '%Y-%m-%d')
        EndDate = DT.datetime.strptime(EndDateHead, '%Y-%m-%d')

        #opening revinue and expenses files
        f = open('revenue.dat', 'r')
        g = open('expenses.dat', 'r')

        #setting counter to 0
        TotalNumRevenue = 0
        TotalTransAmt = 0
        TotalRevHST = 0
        TotalRevTotal = 0
        TotalNumExpense = 0
        TotalItemTotal = 0
        TotalExpHST = 0
        TotalExpTotal = 0

        #printing the heading of the report
        print("HAB Taxi Services")
        print(f"Profit Listing Report From {StartDateHead} to {EndDateHead}")
        print("")
        print("="*120)
        print("                                                         REVENUES")
        print("                                                 =======================")
        print("TRANS    TRANS         DRIVER                     EMPLOYEE                  TRANS            TRANS       HST     TOTAL")
        print("ID        DATE         NUMBER                      NAME                     TYPE              AMT")
        print("="*120)

        # removing unwanted characters
        for Line in f:
            for R in BadChars:
                Line = Line.replace(R, '')
            Line = Line.split(",")

            #removing the space from the date so it can convert to strptime
            CheckDate = Line[1].replace(' ','')

            #converting the date to strptime
            CheckDate = DT.datetime.strptime(CheckDate, '%Y-%m-%d')

            #checking if the revenue date is between the start and end date selected
            if StartDate < CheckDate < EndDate:
                h = open('employees.dat', 'r')

                # removing unwanted characters
                for LineEmp in h:
                    for R in BadChars:
                        LineEmp = LineEmp.replace(R, '')
                    LineEmp = LineEmp.split(",")

                    #matching the employee number to a name
                    if LineEmp[0] == Line[3].replace(' ', ''):
                        EmployeeName = LineEmp[1]

                #formating the prices to print
                TransAmt = float(Line[4])
                TotalTransAmt = TotalTransAmt + TransAmt
                TransAmtStr = f"${TransAmt:,.2f}"
                TotalTransAmtStr = f"${TotalTransAmt:,.2f}"
                RevHST = float(Line[5])
                TotalRevHST = TotalRevHST + RevHST
                RevHSTStr = f"${RevHST:,.2f}"
                TotalRevHSTStr = f"${TotalRevHST:,.2f}"
                RevTotal = float(Line[6])
                TotalRevTotal = TotalRevTotal + RevTotal
                RevTotalStr = f"${RevTotal:,.2f}"
                TotalRevTotalStr = f"${TotalRevTotal:,.2f}"

                #printing the expenses for every loop
                print(f"{Line[0]:>4}     {Line[1]:>10}    {Line[3]:>5}      {EmployeeName:>25}      {Line[2]:>20}   {TransAmtStr:>9}    {RevHSTStr:>7}  {RevTotalStr:>9}")

                #counting how many times the program looped
                TotalNumRevenue = TotalNumRevenue + 1

        #printing the top of the expenses section
        print("=" * 120)
        print(f"Total Number of Revenue: {TotalNumRevenue:<4}                                                              {TotalTransAmtStr:>10}  {TotalRevHSTStr:>9} {TotalRevTotalStr:>10}")
        print("=" * 120)
        print("                                                         EXPENSES")
        print("                                                 =======================")
        print("INV       INV     DRIVER          EMPLOYEE          ITEM        ITEM       COST     QTY     ITEM         HST       TOTAL")
        print("NUMBER    DATE    NUMBER            NAME            NUM         TYPE                       TOTAL")
        print("=" * 120)

        # removing unwanted characters
        for Line in g:
            for R in BadChars:
                Line = Line.replace(R, '')
            Line = Line.split(",")

            # removing the space from the date so it can convert to strptime
            CheckDate = Line[1].replace(' ', '')

            # converting the date to strptime
            CheckDate = DT.datetime.strptime(CheckDate, '%Y-%m-%d')

            # checking if the revenue date is between the start and end date selected
            if StartDate < CheckDate < EndDate:
                h = open('employees.dat', 'r')

                # removing unwanted characters
                for LineEmp in h:
                    for R in BadChars:
                        LineEmp = LineEmp.replace(R, '')
                    LineEmp = LineEmp.split(",")

                    # matching the employee number to a name
                    if LineEmp[0] == Line[2].replace(' ', ''):
                        EmployeeName = LineEmp[1]

                # formating the prices to print
                ItemCost = float(Line[5])
                ItemCostStr = f"${ItemCost:,.2f}"

                ItemTotal = float(Line[7])
                TotalItemTotal = TotalItemTotal + ItemTotal
                ItemTotalStr = f"${ItemTotal:,.2f}"
                TotalItemTotalStr = f"${TotalItemTotal:,.2f}"

                ExpHST = ItemTotal * HSTRate
                TotalExpHST = TotalExpHST + ExpHST
                ExpHSTStr = f"${ExpHST:,.2f}"
                TotalExpHSTStr = f"${TotalExpHST:,.2f}"

                ExpTotal = ItemTotal + ExpHST
                ExpTotalStr = f"${ExpTotal:,.2f}"

                TotalExpTotal = TotalExpTotal + ExpTotal
                TotalExpTotalStr = f"${TotalExpTotal:,.2f}"

                #printing the expenses for every loop
                print(f"{Line[0]:>4}   {Line[1]:>10}  {Line[2]:>4}  {EmployeeName:>24}    {Line[3]:>2}    {Line[4]:>10}    {ItemCostStr:>9}  {Line[6]:>2}   {ItemTotalStr:>9}    {ExpHSTStr:>7}  {ExpTotal:>9}")

                # counting how many times the program looped
                TotalNumExpense = TotalNumExpense + 1
        print("=" * 120)
        print(
            f"Total Number of Expenses: {TotalNumExpense:<4}                                                              {TotalItemTotalStr:>10}  {TotalExpHSTStr:>9} {TotalExpTotalStr:>10}")
        print("=" * 120)

        #printing the total revenue expenses and profit
        TotalProfit = TotalRevTotal - TotalExpTotal
        TotalProfitStr = f"${TotalProfit:,.2f}"
        print(f"                                                                      Total Revenues:                        {TotalRevTotalStr:>10}")
        print(f"                                                                      Total Expenses:                        {TotalExpTotalStr:>10}")
        print("                                                                     ===================================================")
        print(f"                                                                      Total Profit(Loss):                    {TotalProfitStr:>10}")
        print(" ")

        #closing the files
        f.close()
        g.close()
        h.close()
    #running option 7 if the user selects 7
    if Choice == "7":

        # getting the user to enter the start and end date
        StartDateHead = input("what is the start date of the report (YYYY-MM-DD)")
        EndDateHead = input("what is the end date of the report (YYYY-MM-DD)")
        EmpNum = input("please enter the employee number")
        # converting the start and end date to strptime
        StartDate = DT.datetime.strptime(StartDateHead, '%Y-%m-%d')
        EndDate = DT.datetime.strptime(EndDateHead, '%Y-%m-%d')

        # opening revinue.dat
        f = open('revenue.dat', 'r')

        #the heading of the print statement
        print("HAB Taxi Services")
        print(f"Driver Financial Listing from {StartDateHead} to {EndDateHead}")
        print(" ")
        print("TRANSACTION     DRIVER   TRANSACTION       TRANSACTION    TRANSACTION    HST        TOTAL")
        print("    ID          NUMBER      DATE              TYPE          AMMOUNT")
        print("=" * 92)

        #setting variables to 0
        TotalTransAmt = 0
        TotalHST = 0
        TotalTotal = 0
        TotalTransactions = 0

        #removing the characters i dont want
        for Line in f:
            for R in BadChars:
                Line = Line.replace(R, '')
            Line = Line.split(",")

            #removing the space from the date so it can convert to strptime
            CheckDate = Line[1].replace(' ','')

            #converting the date to strptime
            CheckDate = DT.datetime.strptime(CheckDate, '%Y-%m-%d')

            #checking if the revenue date is between the start and end date selected
            if StartDate < CheckDate < EndDate:

                #removing the space from the emplyee number
                CheckNum = Line[3].replace(' ','')

                #checking to see if the employee number entered matches the one in the line of the file
                if CheckNum == EmpNum:

                    #converting the numbers to formated strings
                    TransAmt = float(Line[4])
                    TransAmtStr = f"${TransAmt:,.2f}"

                    TotalTransAmt = TotalTransAmt + TransAmt
                    TotalTransAmtStr = f"${TotalTransAmt:,.2f}"

                    HST = float(Line[5])
                    HSTStr = f"${HST:,.2f}"

                    TotalHST = TotalHST + HST
                    TotalHSTStr = f"${TotalHST:,.2f}"

                    Total = float(Line[6])
                    TotalStr = f"${Total:,.2f}"

                    TotalTotal = TotalTotal + Total
                    TotalTotalStr = f"${TotalTotal:,.2f}"

                    #printing the report every loop
                    print(f"  {Line[0]:>4}          {Line[3]:>4}    {Line[1]:>10}  {Line[2]:>20} {TransAmtStr:>9}   {HSTStr:>7}  {TotalStr:>10}")
                    TotalTransactions = TotalTransactions + 1

        print("=" * 92)
        print(f"Total Amount of Transactions: {TotalTransactions:<5}                       {TotalTransAmtStr:>10} {TotalHSTStr:>9} {TotalTotalStr:>11}")
        print(" ")

    #exiting the program if the user selects 8
    if Choice == "8":
        break